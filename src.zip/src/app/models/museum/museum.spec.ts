import { Museum } from './museum';

describe('Museum', () => {
  it('should create an instance', () => {
    expect(new Museum()).toBeTruthy();
  });
});
