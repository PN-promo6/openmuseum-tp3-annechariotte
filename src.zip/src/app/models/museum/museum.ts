export class Museum {
    _id: string;
    opening: string;
    name: string;
    night_time: string;
    city: string;
    fax: string;
    coordinates: number[];
    website: string;
    telephone: string;
    annual_closure: string;
    address: string;
    cp: string
}
